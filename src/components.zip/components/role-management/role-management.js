import React from 'react';

class RoleManagement extends React.Component{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                这是角色管理
            </div>
        );
    }

}

export default RoleManagement