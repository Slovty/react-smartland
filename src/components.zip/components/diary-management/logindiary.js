import React from 'react';
class LoginDiary extends React.Component{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                这是日志登录管理
            </div>
        );
    }

}

export default LoginDiary