import React from 'react';

class DiaryManagement extends React.Component{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                这是日志操作管理
            </div>
        );
    }

}

export default DiaryManagement