import React from 'react';

class AuthorityManagement extends React.Component{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                这是权限管理
            </div>
        );
    }

}

export default AuthorityManagement