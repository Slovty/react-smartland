import React from 'react';

class UserManagement extends React.Component{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                这是用户管理
            </div>
        );
    }

}

export default UserManagement