import React from 'react';

class InstitutionManagement extends React.Component{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                这是机构管理
            </div>
        );
    }

}

export default InstitutionManagement